'use client';

import React, { useState } from 'react';
import { Layout, Menu, Button, message, theme } from 'antd';
import { 
  AppstoreOutlined, 
  TeamOutlined, 
  SafetyCertificateOutlined, 
  DatabaseOutlined, 
  SettingOutlined,
  LeftOutlined,
  RightOutlined
} from '@ant-design/icons';
import { useRouter } from 'next/navigation';

const { Header, Sider, Content } = Layout;

export default function AdminLayoutClient({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const router = useRouter();
  const { token: { colorBgContainer } } = theme.useToken();

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    message.info('Đã đăng xuất hệ thống!');
    router.push('/login'); 
  };

  const menuItems = [
    { key: '1', icon: <AppstoreOutlined />, label: 'Tổng quan' },
    { key: '2', icon: <TeamOutlined />, label: 'Quản lý Tài khoản' },
    { key: '3', icon: <SafetyCertificateOutlined />, label: 'Phân quyền & Vai trò' },
    { key: '4', icon: <DatabaseOutlined />, label: 'Danh mục chung' },
    { key: '5', icon: <SettingOutlined />, label: 'Cấu hình hệ thống' },
  ];

  const siderWidth = 240;
  const collapsedWidth = 80;

  return (
    <Layout style={{ minHeight: '100vh' }}>
      
      {/* Nút thu gọn đã được dời xuống chính giữa màn hình */}
      <Button 
        type="primary"
        shape="circle"
        icon={collapsed ? <RightOutlined /> : <LeftOutlined />}
        onClick={() => setCollapsed(!collapsed)}
        style={{
          position: 'fixed',
          top: '50%', // Đẩy xuống giữa màn hình
          transform: 'translateY(-50%)', // Căn chỉnh lại tâm của nút
          left: collapsed ? collapsedWidth - 16 : siderWidth - 16, 
          zIndex: 101, 
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
          transition: 'left 0.2s', 
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      />

      <Sider 
        trigger={null}
        collapsible 
        collapsed={collapsed}
        width={siderWidth}
        collapsedWidth={collapsedWidth}
        style={{
          overflow: 'auto',
          height: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          zIndex: 100,
        }}
      >
        <div style={{ height: 40, margin: 16, background: 'rgba(255, 255, 255, 0.2)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 'bold', transition: 'all 0.2s', fontSize: collapsed ? 12 : 16 }}>
          {!collapsed ? 'ADMIN ROOT' : 'AR'}
        </div>
        
        <Menu 
          theme="dark" 
          defaultSelectedKeys={['1']} 
          mode="inline"
          items={menuItems}
          onClick={(e) => {
            if (e.key === '1') router.push('/');
            if (e.key === '2') router.push('/accounts');
            if (e.key === '3') router.push('/roles');
            if (e.key === '4') router.push('/categories');
            if (e.key === '5') router.push('/settings'); 
          }}
        />
      </Sider>
      
      <Layout style={{ marginLeft: collapsed ? collapsedWidth : siderWidth, transition: 'all 0.2s' }}>
        
        <Header style={{ 
          padding: '0 24px', 
          background: colorBgContainer, 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          position: 'sticky', 
          top: 0,
          zIndex: 99,
          boxShadow: '0 1px 4px rgba(0,0,0,0.05)'
        }}>
          <h2 style={{ margin: 0, color: 'black', fontSize: '18px' }}>System Admin Dashboard</h2>
          <Button type="default" onClick={handleLogout}>Đăng xuất</Button>
        </Header>
        
        <Content style={{ margin: '24px', overflow: 'initial' }}>
          {children}
        </Content>

      </Layout>
    </Layout>
  );
}