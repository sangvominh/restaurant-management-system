import './globals.css';
import AdminLayoutClient from './AdminLayoutClient';

export const metadata = {
  title: 'Hệ thống Quản lý MRP Nhà hàng',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="vi">
      <body style={{ margin: 0, padding: 0 }}>
        {/* Gọi file giao diện Client để bọc lấy các trang */}
        <AdminLayoutClient>
          {children}
        </AdminLayoutClient>
      </body>
    </html>
  );
}